tal and ron c project
github